<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Dosen;
use Illuminate\Http\Request;
use Inertia\Inertia;

class DosenController extends Controller
{
    public function index()
    {
        $dosen = Dosen::with('user')->paginate(10);
        return Inertia::render('Admin/Dosen', ["dosen" => $dosen]);
    }
}
